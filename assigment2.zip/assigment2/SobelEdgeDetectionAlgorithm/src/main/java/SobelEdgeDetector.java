import org.apache.commons.imaging.ImageFormats;
import org.apache.commons.imaging.ImageReadException;
import org.apache.commons.imaging.ImageWriteException;
import org.apache.commons.imaging.Imaging;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SobelEdgeDetector {

  // needs flag ?
  public static BufferedImage getImageFromFile(String filename) throws IOException, ImageReadException {
    var file = new File(filename);
    return Imaging.getBufferedImage(file);
  }

  public static void writeImageInto(String filename, BufferedImage result) throws ImageWriteException, IOException {
    Imaging.writeImage(result, new File(filename), ImageFormats.PPM, null);
  }

// return the requested relative matrix quadrant (quarter)
  public static GridChunkBounds getMatrixQuadrantBoundedIndices(int quadrantRelativeOrder, int height, int width) throws Exception {
    // auto halfOfRowNbr = matrix.length / 2;
    // auto halfOfColumnNbr = matrix[0].length / 2;
    int halfOfRowNbr = height / 2;
    int halfOfColumnNbr = width / 2;

    //auto quadrant = new int[halfOfRowNbr][halfOfColumnNbr];

    int startI = 1; // think
    int endI = halfOfRowNbr;
    int startJ = 1;
    int endJ = halfOfColumnNbr;

    // encode where the indexes are initially positioned in the input matrix
    if (quadrantRelativeOrder == 1) {
      // NTD
    } else if (quadrantRelativeOrder == 2) {
      startJ = halfOfColumnNbr;
      endJ = width;
    } else if (quadrantRelativeOrder == 3) {
      startI = halfOfRowNbr;
      endI = height;
    } else if (quadrantRelativeOrder == 4) {
      startI = halfOfRowNbr;
      startJ = halfOfColumnNbr;
      endI = height;
      endJ = width;
    } else {
      throw new Exception("The specified quadrantRelativeOrder should be comprised between 1 and 4;");
    }

    return new GridChunkBounds(startI, endI, startJ, endJ);
  }

  public static BufferedImage computeResultingSobelImageFrom(BufferedImage image, int threshold) throws Exception {
    final int height = image.getHeight();
    final int width = image.getWidth();

    final BufferedImage newImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    // Runtime.getRuntime().availableProcessors()
    final int numberOfThreads = 4;
    final ExecutorService pool = Executors.newFixedThreadPool(numberOfThreads);

    for (int n = 0; n < numberOfThreads; n++) {
      final var gridChunkBounds = getMatrixQuadrantBoundedIndices(n + 1, height, width);

      pool.execute(
          () -> {
            for (int y = gridChunkBounds.startI; y < gridChunkBounds.endI - 1; y++) {
              for (int x = gridChunkBounds.startJ; x < gridChunkBounds.endJ - 1; x++) {
                int sum1 =
                    new Color(image.getRGB(x + 1, y - 1)).getRed()
                        - new Color(image.getRGB(x - 1, y - 1)).getRed()
                        + 2 * new Color(image.getRGB(x + 1, y)).getRed()
                        - 2 * new Color(image.getRGB(x - 1, y)).getRed()
                        + new Color(image.getRGB(x + 1, y + 1)).getRed()
                        - new Color(image.getRGB(x - 1, y + 1)).getRed();

                int sum2 =
                    new Color(image.getRGB(x - 1, y - 1)).getRed()
                        + 2 * new Color(image.getRGB(x, y - 1)).getRed()
                        + new Color(image.getRGB(x + 1, y - 1)).getRed()
                        - new Color(image.getRGB(x - 1, y + 1)).getRed()
                        - 2 * new Color(image.getRGB(x, y + 1)).getRed()
                        - new Color(image.getRGB(x + 1, y + 1)).getRed();

                int magnitude = sum1 * sum1 + sum2 * sum2;

                if (magnitude > threshold) newImage.setRGB(x, y, 16777215); // correspond to 255
                else newImage.setRGB(x, y, 0);
              }
            }
          });
    }

    pool.shutdown();
    while (!pool.isTerminated()) {}

    return newImage;
  }

  public static void main(String[] args) throws Exception {
    // todo support custom filenames
    final int DEFAULT_THRESHOLD = 4000;
    final String DEFAULT_INPUT_FILENAME = "BWstop-sign.ppm";
    final String DEFAULT_OUTPUT_FILENAME = "result.ppm";

    final BufferedImage image = getImageFromFile(DEFAULT_INPUT_FILENAME);

    var startTime = Instant.now();

    final BufferedImage newImage = computeResultingSobelImageFrom(image, DEFAULT_THRESHOLD);

    Instant endTime = Instant.now();
    System.out.println(Duration.between(startTime, endTime));

    writeImageInto(DEFAULT_OUTPUT_FILENAME, newImage);

  }
}
