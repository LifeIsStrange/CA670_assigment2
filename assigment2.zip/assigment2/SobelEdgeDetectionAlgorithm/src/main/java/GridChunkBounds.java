public class GridChunkBounds {
    public final int startI;
    public final int endI;
    public final int startJ;
    public final int endJ;

    public GridChunkBounds(final int startI, final int endI, final int startJ, final int endJ) {
        this.startI = startI;
        this.endI = endI;
        this.startJ = startJ;
        this.endJ = endJ;
    }
}
