rootProject.name = "SobelEdgeDetectionAlgorithm"

